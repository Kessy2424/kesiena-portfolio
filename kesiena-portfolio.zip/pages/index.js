
import Head from 'next/head';

export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-900 p-6 font-sans">
      <Head>
        <title>Kesiena Ileleji | Virtual Assistant</title>
      </Head>
      <header className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Kesiena Ileleji</h1>
        <p className="text-lg">Virtual Assistant & Data Entry Specialist</p>
        <p className="text-sm text-gray-600">Remote | Based in the Netherlands</p>
      </header>
      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">About Me</h2>
        <p>
          I'm a detail-oriented and tech-savvy Virtual Assistant with expertise in data entry,
          calendar and email management, and digital organization. I’ve successfully completed
          the ALX Virtual Assistant program and Google Cybersecurity Certificate, and I bring
          a blend of administrative excellence and technical awareness to every task I handle.
        </p>
      </section>
      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Services Offered</h2>
        <ul className="list-disc list-inside">
          <li>Data Entry & Spreadsheet Management</li>
          <li>Email and Calendar Management</li>
          <li>Document Organization & File Management</li>
          <li>Online Research</li>
          <li>Customer Support Assistance</li>
        </ul>
      </section>
      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Tools & Skills</h2>
        <ul className="list-disc list-inside">
          <li>Google Workspace (Docs, Sheets, Calendar, Drive)</li>
          <li>Microsoft Office Suite (Word, Excel)</li>
          <li>Trello, Notion, Zoom</li>
          <li>Attention to Detail & Time Management</li>
          <li>Beginner Python, Linux, SQL (via Google Certificate)</li>
        </ul>
      </section>
      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Certifications</h2>
        <ul className="list-disc list-inside">
          <li>
            ALX Virtual Assistant Certificate – ALX Africa
          </li>
          <li>
            Google Cybersecurity Professional Certificate – <a href="https://coursera.org/verify/professional-cert/XGOQFL3J0OI0" className="text-blue-600 underline" target="_blank">Verify Credential</a>
          </li>
        </ul>
      </section>
      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Contact</h2>
        <p>Email: kesiena@email.com</p>
        <p>LinkedIn: <a href="https://linkedin.com/in/kesiena-ileleji" className="text-blue-600 underline">linkedin.com/in/kesiena-ileleji</a></p>
      </section>
    </div>
  );
}
